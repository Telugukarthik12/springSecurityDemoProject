# Fullstack project with JWT authentication

Explanatory video: https://youtu.be/YUqi1IjLX8I

The current project shows how to authenticate with JWT from an Angular frontend to a Spring Boot backend.

You can find more details in the README files of the respective folders.
